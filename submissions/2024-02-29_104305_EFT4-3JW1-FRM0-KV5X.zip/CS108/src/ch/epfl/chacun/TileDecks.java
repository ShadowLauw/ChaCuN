package ch.epfl.chacun;

import java.util.List;
import java.util.function.Predicate;

/**
 * Represents the different decks of tiles
 *
 * @author Laura Paraboschi (364161)
 * @author Emmanuel Omont (372632)
 *
 * @param startTiles (List<Tile>) the start tiles deck (composed of only the start tile)
 * @param normalTiles (List<Tile>) the normal tiles deck
 * @param menhirTiles (List<Tile>) the menhir tiles deck
 */
public record TileDecks(List<Tile> startTiles, List<Tile> normalTiles, List<Tile> menhirTiles) {
    /**
     * Default Constructor for TileDeck, make copies of all the decks so that it cannot be modified otherwise
     * @param startTiles (List<Tile>) the start tiles deck (composed of only the start tile)
     * @param normalTiles (List<Tile>) the normal tiles deck
     * @param menhirTiles (List<Tile>) the menhir tiles deck
     */
    public TileDecks {
        startTiles = List.copyOf(startTiles);
        normalTiles = List.copyOf(normalTiles);
        menhirTiles = List.copyOf(menhirTiles);
    }
    /**
     * Returns the size of the deck of the given kind
     * @param kind (Tile.Kind) the kind of deck
     * @return (int) the size of the deck of the given kind
     */
    public int deckSize(Tile.Kind kind) {
        return switch(kind) {
            case START -> startTiles.size();
            case NORMAL -> normalTiles.size();
            case MENHIR -> menhirTiles.size();
        };
    }
    /**
     * Returns the top tile of the deck of the given kind
     * @param kind (Tile.Kind) the kind of deck
     * @return (Tile) the top tile of the deck of the given kind or null if the deck is empty
     */
    public Tile topTile (Tile.Kind kind) {
        List<Tile> tileDeckToSend = switch(kind) {
            case START -> startTiles;
            case NORMAL -> normalTiles;
            case MENHIR -> menhirTiles;
        };
        return tileDeckToSend.isEmpty() ? null : tileDeckToSend.getFirst();
    }
    /**
     * Returns a new TileDecks with the top tile of the given kind removed
     * @param kind (Tile.Kind) the kind of deck
     * @return (TileDecks) a new TileDecks with the top tile of the given kind removed
     * @throws IllegalArgumentException if the deck of the given kind is empty
     */
    public TileDecks withTopTileDrawn(Tile.Kind kind) {
        Preconditions.checkArgument(deckSize(kind) > 0);
        return switch (kind) {
            case START -> new TileDecks(startTiles.subList(1, startTiles.size()), normalTiles, menhirTiles);
            case NORMAL -> new TileDecks(startTiles, normalTiles.subList(1, normalTiles.size()), menhirTiles);
            case MENHIR -> new TileDecks(startTiles, normalTiles, menhirTiles.subList(1, menhirTiles.size()));
        };
    }
    /**
     * Returns a new TileDecks with the top tile of the given kind drawn until the given predicate is satisfied
     * @param kind (Tile.Kind) the kind of deck
     * @param predicate (Predicate<Tile>) the predicate to satisfy
     * @return (TileDecks) a new TileDecks with the top tile of the given kind drawn until the given predicate is satisfied
     */
    public TileDecks withTopTileDrawnUntil(Tile.Kind kind, Predicate<Tile> predicate) {
        TileDecks newTileDeck = new TileDecks(this.startTiles, this.normalTiles, this.menhirTiles);
        Tile topTile = newTileDeck.topTile(kind);
        while (topTile != null && !predicate.test(topTile)) {
            newTileDeck = newTileDeck.withTopTileDrawn(kind);
            topTile = newTileDeck.topTile(kind);
        }
        return newTileDeck;
    }
}
